import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, query, where, orderBy, limit, getDocs } from 'firebase/firestore';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const city = searchParams.get('city');
  const intent = searchParams.get('intent'); // Venta, Alquiler
  const propType = searchParams.get('type');
  const minBudget = parseFloat(searchParams.get('minBudget') || '0');
  const maxBudget = parseFloat(searchParams.get('maxBudget') || '999999999');
  const pageSize = parseInt(searchParams.get('limit') || '20');

  try {
    let qConstraints: any[] = [orderBy('created_at', 'desc'), limit(pageSize)];

    if (city) qConstraints.push(where('city', '==', city));
    if (intent) qConstraints.push(where('intent', '==', intent));
    if (propType) qConstraints.push(where('propertyType', '==', propType));
    
    // Note: Multiple range filters in Firestore require composite indexes. 
    // For simplicity, we filter budget in-memory if we have many posts, 
    // or just assume simple equality for now if needed.
    // However, let's try basic range if only one is used.
    
    let q = query(collection(db, 'posts'), ...qConstraints);

    const snapshot = await getDocs(q);
    let posts = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as any[];

    // In-memory filter for budget to avoid index complexity for now
    if (minBudget > 0 || maxBudget < 999999999) {
      posts = posts.filter(p => {
        const b = typeof p.budget === 'number' ? p.budget : parseFloat(p.budget);
        if (isNaN(b)) return true; // Keep if no budget specified?
        return b >= minBudget && b <= maxBudget;
      });
    }

    return NextResponse.json({ posts });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to fetch posts';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
