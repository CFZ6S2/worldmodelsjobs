import createMiddleware from 'next-intl/middleware';

export default createMiddleware({
  locales: ['en', 'es', 'fr', 'ru', 'pt-BR'],
  defaultLocale: 'en',
  localePrefix: 'as-needed', // English has no prefix: /feed, others: /es/feed
});

export const config = {
  matcher: ['/((?!api|_next|_vercel|.*\\..*).*)'],
};
